# AURIVA SURFACE
Hand-coded full-stack website starter. No AI website-builder is used in the project source.

## Navigation
Home | Products | Collections | Tiles Calculator | Projects | About Us | Manufacturing | Local Dealer | Contact Us

## Product categories
- 400 × 400 mm Parking Tiles
- 500 × 500 mm Parking Tiles
- 600 × 1200 mm Vitrified Flooring & Wall Tiles
- 15 mm Large Slabs

## Company
AURIVA SURFACE — Surface / Tile & Slab Manufacturing Company
9-B National Highway, Patel Road, At Lakdadhar, Ta. Wankaner, Gujarat – 363623, India
+91 8407072626
aurivasurface@gmail.com

## Run
Backend: `cd backend && npm install && npm start`
Frontend: serve `frontend` with any static server, or open `frontend/index.html` for the prototype.
