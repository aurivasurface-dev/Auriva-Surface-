import express from 'express';import cors from 'cors';import fs from 'fs';import path from 'path';
const app=express();app.use(cors());app.use(express.json());const dataDir=path.resolve('data');fs.mkdirSync(dataDir,{recursive:true});const file=path.join(dataDir,'enquiries.json');if(!fs.existsSync(file))fs.writeFileSync(file,'[]');
app.get('/api/health',(req,res)=>res.json({ok:true,company:'AURIVA SURFACE'}));
app.get('/api/products',(req,res)=>res.json([{size:'400 × 400 mm',category:'Parking Tiles'},{size:'500 × 500 mm',category:'Parking Tiles'},{size:'600 × 1200 mm',category:'Vitrified Flooring & Wall Tiles'},{size:'15 mm',category:'Large Slabs'}]));
app.post('/api/enquiries',(req,res)=>{const list=JSON.parse(fs.readFileSync(file));const item={id:Date.now().toString(),createdAt:new Date().toISOString(),...req.body};list.push(item);fs.writeFileSync(file,JSON.stringify(list,null,2));res.status(201).json({success:true,id:item.id})});
app.listen(4000,()=>console.log('AURIVA backend running on http://localhost:4000'));
